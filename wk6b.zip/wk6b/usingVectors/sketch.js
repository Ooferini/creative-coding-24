let position; // location x & y
let velocity; // speed of x y
let acceleration; // changes of speed on x + y

function setup() {
 // put setup code here
  createCanvas(900, 900);
  background(0);

  position = createVector(100, 100); //<---- other way of creating vectors. this calls the "new" key word
  velocity = createVector(.5, 5.5);
  stroke(255);
  strokeWeight(2);
  fill(127, 127);
}

function draw() {
  background(0);
  position.add(velocity);

  ellipse(position.x, position.y, 20, 20);
  print(position.x);
  print(position.y);

  if( (position.x > width) || (position.x < 0) ){
    velocity.x = velocity.x * -1;
  }
  if( (position.y > height) || (position.y < 0) ){
    velocity.y = velocity.y * -1;
  }
}
