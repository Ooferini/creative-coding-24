let xVals = []; // declaring an empty array
let yVals = [];

let num;

function setup() {
 // put setup code here
  createCanvas(1200, 1200);
  fill(255, 102);
  num = 50;
  noStroke();
  //frameRate(5);

}

function draw() {
  background(0);
  // use a for-loop to vist every spot in the array
  // take what's in the previous spot, and move to current spot
  for(let i = num - 1; i > 0; i--){
    xVals[i] = xVals[i-1];
    yVals[i] = yVals[i-1];
    //print(xVals[i]);
  }

  xVals[0] = mouseX;
  yVals[0] = mouseY;
 // utilizing the array:
  for(let i = 0; i < num; i++){
    ellipse(xVals[i], yVals[i], num - i/2.0, num - i/2.0);

  }


}
