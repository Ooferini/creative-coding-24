let p1;
let p2;
let p3;

function setup() {
  createCanvas(800, 800);
  p1 = new Particle(width/2, height/2, -0.0001, .01);
  p2 = new Particle(0, 0, .0001, .001);
}

function draw() {
  // put drawing code here
  background(0);

  p1.update();
  p1.checkEdges();
  p1.display();

  p2.update();
  p2.checkEdges();
  p2.display();
  


}
