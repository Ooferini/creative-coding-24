let img;
let nPoints;
let xPos;
let yPos;

//loads before setup;
//only put heavy stuff ie, loading data here
function preload(){
  img = loadImage("data/cursor_with_shadow_15x21.png");

}


function setup() {
 // put setup code here
  createCanvas(800, 800);
  background(255);
  nPoints = 100;
  // making a new array of a particular length; ps, we are making objects!
  xPos = new Array(nPoints);
  yPos = new Array(nPoints);
  noCursor();

}

function draw() {
 background(253);
 stroke(0, 0, 0);
 strokeJoin(ROUND);
 strokeWeight(8);

xPos[nPoints - 1] = mouseX; // adding a new value to the end of the array
yPos[nPoints - 1] = mouseY; 

for(let i = 0; i < (nPoints - 1); i++){
  line(xPos[i], yPos[i], xPos[i+1], yPos[i+1]);
  xPos[i] = xPos[i+ 1];
  yPos[i] = yPos[i+ 1];

}
 image(img, mouseX, mouseY, 15*6, 21*6);
}
